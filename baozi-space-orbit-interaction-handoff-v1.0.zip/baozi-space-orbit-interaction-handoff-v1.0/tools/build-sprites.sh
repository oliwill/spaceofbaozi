#!/usr/bin/env bash
set -euo pipefail

package_root="$(cd "$(dirname "$0")/.." && pwd)"
workspace_root="$(cd "$package_root/.." && pwd)"
work_dir="$package_root/.work/person"

dog_source="$workspace_root/generated_images/exec-77a710c9-ca01-4f65-8c37-1818a4eadd4e.png"
person_top_source="$workspace_root/generated_images/exec-14194190-bc5f-4ad0-afdc-7d83633c0c6c.png"
person_rear_source="$workspace_root/generated_images/exec-3aa8f4fd-398c-4983-8d82-8d7c93287303.png"
preview_source="$workspace_root/generated_images/exec-83bd5631-84f6-4998-97b2-82f4a75aa0f0.png"

mkdir -p "$work_dir"

cp "$dog_source" "$package_root/assets/source/dog-orbit-run-8dir-4f-source.png"
cp "$preview_source" "$package_root/assets/preview/orbit-keyframes.png"

# The generated contact sheet is visually regular but its figures cross nominal
# cell boundaries. These alpha-component bounds preserve every complete figure.
person_boxes=(
  "143x375+246+1"
  "142x367+550+10"
  "144x369+858+8"
  "143x368+1155+9"
  "139x365+251+372"
  "140x363+551+373"
  "136x364+858+372"
  "136x364+1154+372"
)

# The first eight person frames come from the approved clockwise gaze sheet.
# Each frame is normalized to the same baseline and transparent 384 x 342 cell.
for index in $(seq 0 7); do
  convert "$person_top_source" \
    -crop "${person_boxes[$index]}" +repage \
    -channel A -level 15%,100% +channel \
    -trim +repage -resize x310 \
    -background none -gravity south -extent 384x342 \
    "$work_dir/frame-$(printf '%02d' "$index").png"
done

# The rear-sector source has a fully fixed front-facing body. Two right-looking
# poses are mirrored to produce the matching left-looking pair.
for source_index in 0 1; do
  x=$((source_index * 412))
  convert "$person_rear_source" \
    -crop "412x954+${x}+0" +repage \
    -channel A -level 4%,100% +channel \
    -trim +repage -resize x310 \
    -background none -gravity south -extent 384x342 \
    "$work_dir/rear-right-${source_index}.png"
done

convert "$work_dir/rear-right-0.png" -flop "$work_dir/frame-08.png"
convert "$work_dir/rear-right-1.png" -flop "$work_dir/frame-09.png"
cp "$work_dir/rear-right-1.png" "$work_dir/frame-10.png"
cp "$work_dir/rear-right-0.png" "$work_dir/frame-11.png"

convert \
  "$work_dir/frame-00.png" "$work_dir/frame-01.png" \
  "$work_dir/frame-02.png" "$work_dir/frame-03.png" \
  +append "$work_dir/row-0.png"
convert \
  "$work_dir/frame-04.png" "$work_dir/frame-05.png" \
  "$work_dir/frame-06.png" "$work_dir/frame-07.png" \
  +append "$work_dir/row-1.png"
convert \
  "$work_dir/frame-08.png" "$work_dir/frame-09.png" \
  "$work_dir/frame-10.png" "$work_dir/frame-11.png" \
  +append "$work_dir/row-2.png"

convert \
  "$work_dir/row-0.png" "$work_dir/row-1.png" "$work_dir/row-2.png" \
  -append "$package_root/assets/source/person-look-12dir-source.png"

convert "$package_root/assets/source/dog-orbit-run-8dir-4f-source.png" \
  -define webp:lossless=true -quality 92 \
  "$package_root/assets/runtime/dog-orbit-run-8dir-4f.webp"

convert "$package_root/assets/source/person-look-12dir-source.png" \
  -define webp:lossless=true -quality 92 \
  "$package_root/assets/runtime/person-look-12dir.webp"
