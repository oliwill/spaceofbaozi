# 接入说明

## 1. 目标角度

鼠标只提供相对人物中心的方向：

```ts
const dx = pointerX - personCenterX;
const dy = pointerY - personFeetY;

if (Math.hypot(dx, dy) >= pointerDeadZonePx) {
  targetAngle = Math.atan2(dy, dx);
}
```

进入中心死区时保留上一次 `targetAngle`，不要令小狗向人物脚下收缩。

## 2. 最短角路径和阻尼

```ts
const TAU = Math.PI * 2;

function shortestArc(from: number, to: number) {
  return Math.atan2(Math.sin(to - from), Math.cos(to - from));
}

function updateOrbit(dt: number) {
  const error = shortestArc(dogAngle, targetAngle);
  dogAngularVelocity +=
    (error * contract.orbit.angleSpring -
      dogAngularVelocity * contract.orbit.angleDamping) * dt;

  dogAngularVelocity = clamp(
    dogAngularVelocity,
    -contract.orbit.maxAngularSpeedRadPerSec,
    contract.orbit.maxAngularSpeedRadPerSec
  );

  dogAngle += dogAngularVelocity * dt;
}
```

跨过 `0° / 360°` 时必须使用 `shortestArc`，否则小狗会反向跑完整圈。

## 3. 椭圆坐标

```ts
const dogX = personCenterX + Math.cos(dogAngle) * radiusX;
const dogY = personFeetY + Math.sin(dogAngle) * radiusY;
```

轨道中心使用人物脚下，而不是人物图片矩形中心。Hero 尺寸改变后重新计算中心和半径。

## 4. 狗的方向与步态

```ts
const dogDirection = wrap(
  Math.round(dogAngle / (Math.PI / 4)),
  8
);

const dogGaitFrame = moving
  ? Math.floor(elapsedSeconds * contract.dog.gaitFps) % 4
  : 0;
```

对方向索引加入约 `9°` 的迟滞，防止在方向分界线上反复切行。停止误差小于 `3.5°` 后让步态落在接触帧。

## 5. 人物观察帧

人物必须观察小狗的实际渲染位置：

```ts
const actualDogAngle = Math.atan2(
  renderedDogY - personFeetY,
  renderedDogX - personCenterX
);

const personFrame = wrap(
  Math.round(actualDogAngle / (Math.PI / 6)),
  12
);
```

不要直接用 `targetAngle` 或鼠标坐标，否则人物会先于有惯性的小狗转头，看起来像在看空气。

人物帧可以通过一个约 `110ms` 的低通或弹簧延迟跟随，并加入 `7°` 迟滞。精灵表是整身帧，人物元素的左上角和脚底锚点在切帧时保持固定。

## 6. 前后层级

```ts
const depth = Math.sin(dogAngle);

if (depth < -0.08) layer = "behind";
if (depth > 0.08) layer = "front";

const dogScale = 0.98 + depth * 0.06;
```

`-0.08 / 0.08` 构成层级迟滞区，避免小狗经过左右两侧时反复切换 `z-index`。

## 7. 启动动画衔接

1. 人物完成站立帧，固定脚底锚点。
2. 小狗沿启动动画的出场方向进入椭圆，保留速度感。
3. 自动完成约半圈，期间人物已经开始跟随小狗转头。
4. 站稳后 `300ms` 开放鼠标控制。
5. 鼠标离开 Hero 后等待 `900ms`，再缓慢回到右下方 `35°` 休息位。

## 8. CSS 精灵定位

建议元素尺寸等于单帧显示尺寸，使用百分比放大整张背景：

```css
.orbit-dog {
  background-image: url("./dog-orbit-run-8dir-4f.webp");
  background-size: 400% 800%;
  background-position:
    calc(var(--gait-frame) * -100%)
    calc(var(--dog-direction) * -100%);
}

.orbit-person {
  background-image: url("./person-look-12dir.webp");
  background-size: 400% 300%;
  background-position:
    calc(var(--person-col) * -100%)
    calc(var(--person-row) * -100%);
}
```

人物 `col = frame % 4`，`row = Math.floor(frame / 4)`。

## 9. 无障碍与移动端

- `prefers-reduced-motion: reduce`：关闭连续轨道和步态动画，仅在四个固定方位间交叉淡化。
- 触屏：手指拖动只更新目标角度，不阻止页面纵向滚动；只有从角色互动区开始的横向/环形手势才接管。
- 键盘：Hero 聚焦后可用左右方向键按 `15°` 调整小狗位置。
- 所有互动都不应遮挡主导航、标题和链接的点击区域。

