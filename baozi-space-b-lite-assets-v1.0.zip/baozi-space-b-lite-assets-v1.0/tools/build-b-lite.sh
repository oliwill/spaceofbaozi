#!/usr/bin/env bash
set -euo pipefail

WORKSPACE_ROOT="${1:-/workspace/scratch/895d75160fc4}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PACKAGE_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"

INTRO_SRC="${WORKSPACE_ROOT}/baozi-space-a0-v-production-v1.2/design-assets/intro/incoming-production"
ORBIT_SRC="${WORKSPACE_ROOT}/baozi-space-orbit-interaction-handoff-v1.0/assets/source"

INTRO_OUT="${PACKAGE_ROOT}/assets/intro/production"
INTRO_SOURCE_OUT="${PACKAGE_ROOT}/assets/intro/source"
ORBIT_OUT="${PACKAGE_ROOT}/assets/orbit"

mkdir -p \
  "${INTRO_OUT}/person" \
  "${INTRO_OUT}/dog" \
  "${INTRO_OUT}/environment" \
  "${INTRO_OUT}/ball" \
  "${INTRO_SOURCE_OUT}/person" \
  "${INTRO_SOURCE_OUT}/dog" \
  "${INTRO_SOURCE_OUT}/environment" \
  "${ORBIT_OUT}/source" \
  "${ORBIT_OUT}/runtime"

TMP_ROOT="$(mktemp -d)"
trap 'rm -rf "${TMP_ROOT}"' EXIT

make_color_layer() {
  local width="$1"
  local height="$2"
  local color="$3"
  local mask="$4"
  local output="$5"

  convert -size "${width}x${height}" "xc:${color}" \
    "${mask}" -alpha off -compose CopyOpacity -composite \
    "${output}"
}

subtract_masks() {
  local minuend="$1"
  local subtrahend="$2"
  local output="$3"

  convert "${minuend}" "${subtrahend}" \
    -compose Mathematics -define compose:args='0,1,-1,0' -composite \
    "${output}"
}

process_character_frame() {
  local input="$1"
  local output="$2"
  local width="$3"
  local height="$4"
  local tmp="$5"

  mkdir -p "${tmp}"

  # Generated source sheets contain faint matte/speckle alpha outside the
  # actual cutout. Thresholding the support mask removes those fragments while
  # multiplying by the original alpha keeps antialiasing on the retained art.
  convert "${input}" -alpha extract "${tmp}/alpha-original.png"
  convert "${tmp}/alpha-original.png" -threshold 20% \
    -morphology Close Disk:1 "${tmp}/alpha-support.png"
  convert "${tmp}/alpha-original.png" "${tmp}/alpha-support.png" \
    -compose Multiply -composite "${tmp}/alpha.png"
  convert "${input}" "${tmp}/alpha.png" -alpha off -compose CopyOpacity -composite \
    "${tmp}/input-clean.png"

  convert "${tmp}/alpha.png" -morphology Dilate Disk:4 "${tmp}/outer-alpha.png"
  convert "${tmp}/alpha.png" -morphology Erode Disk:1 "${tmp}/eroded-alpha.png"
  subtract_masks "${tmp}/alpha.png" "${tmp}/eroded-alpha.png" "${tmp}/edge-mask.png"
  convert "${tmp}/edge-mask.png" -evaluate Multiply 0.78 "${tmp}/edge-mask-soft.png"

  # The exposed portions of two tiny offset silhouettes mimic restrained
  # blue/green plate misregistration without producing a full drop shadow.
  convert "${tmp}/outer-alpha.png" -roll +2+1 \
    -fill black \
    -draw "rectangle 0,0 1,$((height - 1)) rectangle 0,0 $((width - 1)),0" \
    "${tmp}/outer-shift-blue.png"
  subtract_masks "${tmp}/outer-shift-blue.png" "${tmp}/outer-alpha.png" "${tmp}/blue-mask.png"
  convert "${tmp}/blue-mask.png" -evaluate Multiply 0.26 "${tmp}/blue-mask-soft.png"

  convert "${tmp}/outer-alpha.png" -roll -1-1 \
    -fill black \
    -draw "rectangle $((width - 1)),0 $((width - 1)),$((height - 1)) rectangle 0,$((height - 1)) $((width - 1)),$((height - 1))" \
    "${tmp}/outer-shift-green.png"
  subtract_masks "${tmp}/outer-shift-green.png" "${tmp}/outer-alpha.png" "${tmp}/green-mask.png"
  convert "${tmp}/green-mask.png" -evaluate Multiply 0.18 "${tmp}/green-mask-soft.png"

  # Tone is limited to the dark half of the art and remains sparse.
  convert "${tmp}/input-clean.png" -background white -alpha remove -alpha off \
    -colorspace Gray -threshold 48% -negate "${tmp}/dark-mask.png"
  convert -size 6x6 xc:black -fill white -draw 'circle 1,1 1.75,1' \
    -write mpr:dot +delete -size "${width}x${height}" tile:mpr:dot \
    "${tmp}/dots.png"
  convert "${tmp}/dark-mask.png" "${tmp}/alpha.png" -compose Multiply -composite \
    "${tmp}/dots.png" -compose Multiply -composite \
    -evaluate Multiply 0.18 "${tmp}/tone-mask.png"

  make_color_layer "${width}" "${height}" '#2F6FA0' "${tmp}/blue-mask-soft.png" "${tmp}/blue.png"
  make_color_layer "${width}" "${height}" '#2F6A4A' "${tmp}/green-mask-soft.png" "${tmp}/green.png"
  make_color_layer "${width}" "${height}" '#F7F3E9' "${tmp}/outer-alpha.png" "${tmp}/paper.png"
  make_color_layer "${width}" "${height}" '#243248' "${tmp}/tone-mask.png" "${tmp}/tone.png"
  make_color_layer "${width}" "${height}" '#243248' "${tmp}/edge-mask-soft.png" "${tmp}/edge.png"

  convert -size "${width}x${height}" xc:none \
    "${tmp}/green.png" -compose Over -composite \
    "${tmp}/blue.png" -compose Over -composite \
    "${tmp}/paper.png" -compose Over -composite \
    "${tmp}/input-clean.png" -compose Over -composite \
    "${tmp}/tone.png" -compose Over -composite \
    "${tmp}/edge.png" -compose Over -composite \
    -depth 8 \
    "${output}"
}

process_sprite_sheet() {
  local input="$1"
  local png_output="$2"
  local webp_output="$3"
  local cols="$4"
  local rows="$5"
  local cell_width="$6"
  local cell_height="$7"
  local name="$8"
  local sheet_tmp="${TMP_ROOT}/${name}"

  mkdir -p "${sheet_tmp}"

  local row_images=()
  local row col index x y
  for ((row = 0; row < rows; row += 1)); do
    local frame_images=()
    for ((col = 0; col < cols; col += 1)); do
      index=$((row * cols + col))
      x=$((col * cell_width))
      y=$((row * cell_height))
      convert "${input}" -crop "${cell_width}x${cell_height}+${x}+${y}" +repage \
        "${sheet_tmp}/frame-${index}-source.png"
      process_character_frame \
        "${sheet_tmp}/frame-${index}-source.png" \
        "${sheet_tmp}/frame-${index}.png" \
        "${cell_width}" "${cell_height}" \
        "${sheet_tmp}/frame-${index}-work"
      frame_images+=("${sheet_tmp}/frame-${index}.png")
    done
    convert "${frame_images[@]}" +append "${sheet_tmp}/row-${row}.png"
    row_images+=("${sheet_tmp}/row-${row}.png")
  done

  convert "${row_images[@]}" -append +repage -depth 8 "${png_output}"
  convert "${png_output}" \
    -define webp:method=6 -define webp:alpha-quality=100 -quality 90 \
    "${webp_output}"
}

process_grass() {
  local input="$1"
  local png_output="$2"
  local webp_output="$3"
  local width=2560
  local height=640
  local tmp="${TMP_ROOT}/grass"

  mkdir -p "${tmp}"
  convert "${input}" -alpha extract "${tmp}/alpha.png"
  convert "${tmp}/alpha.png" -morphology Erode Disk:1 "${tmp}/eroded-alpha.png"
  subtract_masks "${tmp}/alpha.png" "${tmp}/eroded-alpha.png" "${tmp}/edge-mask.png"
  convert "${tmp}/edge-mask.png" \
    -fill black \
    -draw "rectangle 0,$((height - 8)) $((width - 1)),$((height - 1)) rectangle 0,0 2,$((height - 1)) rectangle $((width - 3)),0 $((width - 1)),$((height - 1))" \
    -evaluate Multiply 0.50 "${tmp}/edge-mask-soft.png"

  convert "${input}" -background white -alpha remove -alpha off \
    -colorspace Gray -threshold 56% -negate "${tmp}/dark-mask.png"
  convert -size 7x7 xc:black -fill white -draw 'circle 1,1 1.7,1' \
    -write mpr:dot +delete -size "${width}x${height}" tile:mpr:dot \
    "${tmp}/dots.png"
  convert "${tmp}/dark-mask.png" "${tmp}/alpha.png" -compose Multiply -composite \
    "${tmp}/dots.png" -compose Multiply -composite \
    -evaluate Multiply 0.11 "${tmp}/tone-mask.png"

  make_color_layer "${width}" "${height}" '#2F6A4A' "${tmp}/edge-mask-soft.png" "${tmp}/edge.png"
  make_color_layer "${width}" "${height}" '#243248' "${tmp}/tone-mask.png" "${tmp}/tone.png"

  convert -size "${width}x${height}" xc:none \
    "${input}" -compose Over -composite \
    "${tmp}/tone.png" -compose Over -composite \
    "${tmp}/edge.png" -compose Over -composite \
    -depth 8 \
    "${png_output}"
  convert "${png_output}" \
    -define webp:method=6 -define webp:alpha-quality=100 -quality 90 \
    "${webp_output}"
}

process_static_cutout() {
  local input="$1"
  local png_output="$2"
  local webp_output="$3"
  local width="$4"
  local height="$5"
  local name="$6"
  local tmp="${TMP_ROOT}/${name}"
  local webp_tmp="${tmp}/runtime.webp"

  process_character_frame "${input}" "${png_output}" "${width}" "${height}" "${tmp}"
  convert "${png_output}" \
    -define webp:method=6 -define webp:alpha-quality=100 -quality 90 \
    "${webp_tmp}"
  test -s "${webp_tmp}"
  mv "${webp_tmp}" "${webp_output}"
}

normalize_orbit_dog_sheet() {
  local input="$1"
  local output="$2"
  local tmp="${TMP_ROOT}/orbit-dog-normalize"
  local components="${tmp}/components.txt"

  mkdir -p "${tmp}"

  convert "${input}" -alpha extract -threshold 20% \
    -define connected-components:verbose=true -connected-components 8 null: \
    >"${tmp}/connected-components.txt" 2>&1

  awk '$NF == "gray(255)" && $(NF-1) > 1000 {
    bbox=$2;
    normalized=bbox;
    gsub(/[x+]/, " ", normalized);
    split(normalized, part, " ");
    printf "%d\t%d\t%s\n", part[4], part[3], bbox;
  }' "${tmp}/connected-components.txt" \
    | sort -n -k1,1 -k2,2 >"${components}"

  local count
  count="$(wc -l <"${components}")"
  if [[ "${count}" -ne 32 ]]; then
    echo "Expected 32 orbit dog components, found ${count}" >&2
    return 1
  fi

  local index=0
  local row_images=()
  local current_row=0
  local frame_images=()
  while IFS=$'\t' read -r _y _x bbox; do
    convert "${input}" -crop "${bbox}" +repage "${tmp}/crop-${index}.png"
    convert "${tmp}/crop-${index}.png" -alpha extract \
      -threshold 20% -morphology Close Disk:1 "${tmp}/support-${index}.png"
    convert "${tmp}/support-${index}.png" \
      -define connected-components:verbose=true -connected-components 8 null: \
      >"${tmp}/local-components-${index}.txt" 2>&1
    local main_id low_threshold high_threshold
    main_id="$(awk '$NF == "gray(255)" { id=$1; gsub(/:/, "", id); print id; exit }' \
      "${tmp}/local-components-${index}.txt")"
    if [[ -z "${main_id}" ]]; then
      echo "No opaque dog component found for orbit frame ${index}" >&2
      return 1
    fi
    low_threshold="$(awk -v id="${main_id}" 'BEGIN { printf "%.8f%%", (id - 0.5) * 100 / 65535 }')"
    high_threshold="$(awk -v id="${main_id}" 'BEGIN { printf "%.8f%%", (id + 0.5) * 100 / 65535 }')"
    convert "${tmp}/support-${index}.png" -connected-components 8 \
      "${tmp}/labels-${index}.png"
    convert "${tmp}/labels-${index}.png" -threshold "${low_threshold}" \
      "${tmp}/labels-at-or-above-${index}.png"
    convert "${tmp}/labels-${index}.png" -threshold "${high_threshold}" \
      "${tmp}/labels-above-${index}.png"
    convert "${tmp}/labels-at-or-above-${index}.png" "${tmp}/labels-above-${index}.png" \
      -compose MinusSrc -composite "${tmp}/support-main-${index}.png"
    convert "${tmp}/crop-${index}.png" "${tmp}/support-main-${index}.png" \
      -alpha off -compose CopyOpacity -composite \
      -resize '232x176>' "${tmp}/art-${index}.png"

    local art_width art_height offset_x offset_y
    read -r art_width art_height < <(
      identify -format '%w %h\n' "${tmp}/art-${index}.png"
    )
    offset_x=$(((256 - art_width) / 2))
    offset_y=$((192 - 8 - art_height))
    if [[ "${offset_y}" -lt 4 ]]; then
      offset_y=4
    fi

    convert -size 256x192 xc:none \
      "${tmp}/art-${index}.png" -geometry "+${offset_x}+${offset_y}" \
      -compose Over -composite "${tmp}/cell-${index}.png"
    frame_images+=("${tmp}/cell-${index}.png")

    if [[ $(((index + 1) % 4)) -eq 0 ]]; then
      convert "${frame_images[@]}" +append "${tmp}/row-${current_row}.png"
      row_images+=("${tmp}/row-${current_row}.png")
      frame_images=()
      current_row=$((current_row + 1))
    fi
    index=$((index + 1))
  done <"${components}"

  convert "${row_images[@]}" -append +repage -depth 8 "${output}"
}

process_sprite_sheet \
  "${INTRO_SRC}/person/summer-land-stand.webp" \
  "${INTRO_SOURCE_OUT}/person/summer-land-stand-b-lite.png" \
  "${INTRO_OUT}/person/summer-land-stand.webp" \
  4 2 384 384 intro-person-land

process_sprite_sheet \
  "${INTRO_SRC}/person/summer-pulled-run-right.webp" \
  "${INTRO_SOURCE_OUT}/person/summer-pulled-run-right-b-lite.png" \
  "${INTRO_OUT}/person/summer-pulled-run-right.webp" \
  4 2 384 384 intro-person-run

process_sprite_sheet \
  "${INTRO_SRC}/person/summer-trip-exit-right.webp" \
  "${INTRO_SOURCE_OUT}/person/summer-trip-exit-right-b-lite.png" \
  "${INTRO_OUT}/person/summer-trip-exit-right.webp" \
  4 2 384 384 intro-person-trip

process_sprite_sheet \
  "${INTRO_SRC}/dog/dog-circle-settle.webp" \
  "${INTRO_SOURCE_OUT}/dog/dog-circle-settle-b-lite.png" \
  "${INTRO_OUT}/dog/dog-circle-settle.webp" \
  4 2 320 240 intro-dog-settle

process_sprite_sheet \
  "${INTRO_SRC}/dog/dog-run-right.webp" \
  "${INTRO_SOURCE_OUT}/dog/dog-run-right-b-lite.png" \
  "${INTRO_OUT}/dog/dog-run-right.webp" \
  4 2 320 240 intro-dog-run

process_grass \
  "${INTRO_SRC}/environment/intro-grass.webp" \
  "${INTRO_SOURCE_OUT}/environment/intro-grass-b-lite.png" \
  "${INTRO_OUT}/environment/intro-grass.webp"

process_static_cutout \
  "${INTRO_SRC}/intro-final-still.webp" \
  "${INTRO_SOURCE_OUT}/intro-final-still-b-lite.png" \
  "${INTRO_OUT}/intro-final-still.webp" \
  768 768 intro-final-still

process_sprite_sheet \
  "${ORBIT_SRC}/person-look-12dir-source.png" \
  "${ORBIT_OUT}/source/person-look-12dir-b-lite.png" \
  "${ORBIT_OUT}/runtime/person-look-12dir.webp" \
  4 3 384 342 orbit-person

normalize_orbit_dog_sheet \
  "${ORBIT_SRC}/dog-orbit-run-8dir-4f-source.png" \
  "${ORBIT_OUT}/source/dog-orbit-run-8dir-4f-normalized.png"

process_sprite_sheet \
  "${ORBIT_OUT}/source/dog-orbit-run-8dir-4f-normalized.png" \
  "${ORBIT_OUT}/source/dog-orbit-run-8dir-4f-b-lite.png" \
  "${ORBIT_OUT}/runtime/dog-orbit-run-8dir-4f.webp" \
  4 8 256 192 orbit-dog

cp "${INTRO_SRC}/ball/ball-bounce.webp" "${INTRO_OUT}/ball/ball-bounce.webp"
cp "${INTRO_SRC}/intro-manifest.json" "${INTRO_OUT}/intro-manifest.json"

echo "B-lite assets written to ${PACKAGE_ROOT}/assets"
