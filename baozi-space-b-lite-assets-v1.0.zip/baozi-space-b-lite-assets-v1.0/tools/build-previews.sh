#!/usr/bin/env bash
set -euo pipefail

WORKSPACE_ROOT="${1:-/workspace/scratch/895d75160fc4}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PACKAGE_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
QA_OUT="${PACKAGE_ROOT}/qa"

CURRENT_INTRO="${WORKSPACE_ROOT}/baozi-space-a0-v-production-v1.2/design-assets/intro/incoming-production"
BLITE_INTRO_RUNTIME="${PACKAGE_ROOT}/assets/intro/production"
BLITE_INTRO_SOURCE="${PACKAGE_ROOT}/assets/intro/source"
BLITE_ORBIT_SOURCE="${PACKAGE_ROOT}/assets/orbit/source"

mkdir -p "${QA_OUT}"

TMP_ROOT="$(mktemp -d)"
trap 'rm -rf "${TMP_ROOT}"' EXIT

make_grid_canvas() {
  local width="$1"
  local height="$2"
  local output="$3"

  convert -size 24x24 xc:'#F7F3E9' \
    -fill '#D7DDDA' -draw 'circle 2,2 2.8,2' \
    -write mpr:dot +delete \
    -size "${width}x${height}" tile:mpr:dot "${output}"
}

make_intro_panel() {
  local variant="$1"
  local person_sheet="$2"
  local dog_sheet="$3"
  local grass="$4"
  local output="$5"

  make_grid_canvas 800 900 "${TMP_ROOT}/${variant}-grid.png"
  convert "${person_sheet}" -crop 384x384+768+384 +repage \
    -resize 360x360 "${TMP_ROOT}/${variant}-person.png"
  convert "${dog_sheet}" -crop 320x240+640+0 +repage \
    -resize 300x225 "${TMP_ROOT}/${variant}-dog.png"
  convert "${grass}" -resize 800x300! "${TMP_ROOT}/${variant}-grass.png"

  convert "${TMP_ROOT}/${variant}-grid.png" \
    "${TMP_ROOT}/${variant}-grass.png" -geometry +0+510 -compose Over -composite \
    "${TMP_ROOT}/${variant}-person.png" -geometry +78+305 -compose Over -composite \
    "${TMP_ROOT}/${variant}-dog.png" -geometry +425+470 -compose Over -composite \
    -fill '#243248' -font DejaVu-Sans-Bold -pointsize 34 \
    -gravity NorthWest -annotate +48+42 "${variant}" \
    -fill '#53616A' -font DejaVu-Sans -pointsize 18 \
    -annotate +49+88 'same frame geometry · same watercolor identity' \
    "${output}"
}

make_intro_panel \
  'CURRENT' \
  "${CURRENT_INTRO}/person/summer-pulled-run-right.webp" \
  "${CURRENT_INTRO}/dog/dog-run-right.webp" \
  "${CURRENT_INTRO}/environment/intro-grass.webp" \
  "${TMP_ROOT}/current-panel.png"

make_intro_panel \
  'B-LITE' \
  "${BLITE_INTRO_SOURCE}/person/summer-pulled-run-right-b-lite.png" \
  "${BLITE_INTRO_SOURCE}/dog/dog-run-right-b-lite.png" \
  "${BLITE_INTRO_SOURCE}/environment/intro-grass-b-lite.png" \
  "${TMP_ROOT}/b-lite-panel.png"

convert "${TMP_ROOT}/current-panel.png" "${TMP_ROOT}/b-lite-panel.png" +append \
  -stroke 'rgba(36,50,72,0.28)' -strokewidth 2 -draw 'line 800,26 800,874' \
  +repage -depth 8 \
  "${QA_OUT}/intro-current-vs-b-lite.png"

make_orbit_panel() {
  local label="$1"
  local person_index="$2"
  local dog_row="$3"
  local dog_x="$4"
  local dog_y="$5"
  local output="$6"
  local person_col=$((person_index % 4))
  local person_row=$((person_index / 4))

  make_grid_canvas 700 450 "${TMP_ROOT}/${label}-grid.png"
  convert "${BLITE_ORBIT_SOURCE}/person-look-12dir-b-lite.png" \
    -crop "384x342+$((person_col * 384))+$((person_row * 342))" +repage \
    -resize 280x250 "${TMP_ROOT}/${label}-person.png"
  convert "${BLITE_ORBIT_SOURCE}/dog-orbit-run-8dir-4f-b-lite.png" \
    -crop "256x192+0+$((dog_row * 192))" +repage \
    -resize 170x128 "${TMP_ROOT}/${label}-dog.png"

  if [[ "${label}" == 'BACK' ]]; then
    convert "${TMP_ROOT}/${label}-grid.png" \
      "${TMP_ROOT}/${label}-dog.png" -geometry "+${dog_x}+${dog_y}" -compose Over -composite \
      "${TMP_ROOT}/${label}-person.png" -geometry +210+138 -compose Over -composite \
      -fill '#243248' -font DejaVu-Sans-Bold -pointsize 24 \
      -gravity NorthWest -annotate +30+26 "${label}" \
      "${output}"
  else
    convert "${TMP_ROOT}/${label}-grid.png" \
      "${TMP_ROOT}/${label}-person.png" -geometry +210+138 -compose Over -composite \
      "${TMP_ROOT}/${label}-dog.png" -geometry "+${dog_x}+${dog_y}" -compose Over -composite \
      -fill '#243248' -font DejaVu-Sans-Bold -pointsize 24 \
      -gravity NorthWest -annotate +30+26 "${label}" \
      "${output}"
  fi
}

make_orbit_panel EAST 0 0 485 236 "${TMP_ROOT}/orbit-east.png"
make_orbit_panel FRONT 3 2 270 310 "${TMP_ROOT}/orbit-front.png"
make_orbit_panel WEST 6 4 42 236 "${TMP_ROOT}/orbit-west.png"
make_orbit_panel BACK 9 6 270 70 "${TMP_ROOT}/orbit-back.png"

convert "${TMP_ROOT}/orbit-east.png" "${TMP_ROOT}/orbit-front.png" +append "${TMP_ROOT}/orbit-top.png"
convert "${TMP_ROOT}/orbit-west.png" "${TMP_ROOT}/orbit-back.png" +append "${TMP_ROOT}/orbit-bottom.png"
convert "${TMP_ROOT}/orbit-top.png" "${TMP_ROOT}/orbit-bottom.png" -append \
  -stroke 'rgba(36,50,72,0.22)' -strokewidth 2 \
  -draw 'line 700,20 700,880 line 20,450 1380,450' \
  +repage -depth 8 \
  "${QA_OUT}/orbit-b-lite-direction-check.png"

# A compact checker preview makes residual alpha artifacts obvious.
convert -size 32x32 pattern:checkerboard -scale 1600x900! \
  -colorspace sRGB "${TMP_ROOT}/checker.png"
convert "${TMP_ROOT}/checker.png" \
  '(' "${BLITE_INTRO_RUNTIME}/intro-final-still.webp" -resize 760x760 ')' \
  -gravity Center -compose Over -composite \
  +repage -depth 8 \
  "${QA_OUT}/intro-final-still-alpha-check.png"

echo "QA previews written to ${QA_OUT}"
