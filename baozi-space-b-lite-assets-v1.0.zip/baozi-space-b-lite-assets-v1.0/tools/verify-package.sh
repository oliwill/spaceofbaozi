#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PACKAGE_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"

fail() {
  echo "FAIL: $*" >&2
  exit 1
}

assert_image() {
  local relative="$1"
  local expected="$2"
  local path="${PACKAGE_ROOT}/${relative}"
  [[ -s "${path}" ]] || fail "missing or empty ${relative}"
  local actual
  actual="$(identify -format '%wx%h' "${path}")"
  [[ "${actual}" == "${expected}" ]] || fail "${relative}: expected ${expected}, got ${actual}"
}

assert_rgba_and_transparent_corners() {
  local relative="$1"
  local path="${PACKAGE_ROOT}/${relative}"
  local width height channels corners
  read -r width height channels < <(identify -format '%w %h %[channels]\n' "${path}")
  [[ "${channels}" == *a* ]] || fail "${relative} has no alpha channel"
  corners="$(convert "${path}" -alpha extract \
    -format "%[fx:p{0,0}] %[fx:p{$((width - 1)),0}] %[fx:p{0,$((height - 1))}] %[fx:p{$((width - 1)),$((height - 1))}]" info:)"
  awk -v values="${corners}" 'BEGIN {
    split(values, item, " ");
    for (i = 1; i <= 4; i += 1) if (item[i] >= 0.02) exit 1;
  }' || fail "${relative} has a non-transparent canvas corner: ${corners}"
}

assert_sheet_cells_isolated() {
  local relative="$1"
  local cols="$2"
  local rows="$3"
  local cell_width="$4"
  local cell_height="$5"
  local path="${PACKAGE_ROOT}/${relative}"
  local row col index bbox width height x y

  for ((row = 0; row < rows; row += 1)); do
    for ((col = 0; col < cols; col += 1)); do
      index=$((row * cols + col))
      convert "${path}" -crop "${cell_width}x${cell_height}+$((col * cell_width))+$((row * cell_height))" +repage \
        -alpha extract -threshold 20% "${tmp}/cell-check.png"
      bbox="$(identify -format '%@' "${tmp}/cell-check.png")"
      if [[ ! "${bbox}" =~ ^([0-9]+)x([0-9]+)\+([0-9]+)\+([0-9]+)$ ]]; then
        fail "cannot parse ${relative} frame ${index} bounds: ${bbox}"
      fi
      width="${BASH_REMATCH[1]}"
      height="${BASH_REMATCH[2]}"
      x="${BASH_REMATCH[3]}"
      y="${BASH_REMATCH[4]}"
      [[ "${width}" -gt 0 && "${height}" -gt 0 ]] || fail "${relative} frame ${index} is empty"
      [[ "${x}" -ge 1 && "${y}" -ge 1 && $((x + width)) -le $((cell_width - 1)) && $((y + height)) -le "${cell_height}" ]] \
        || fail "${relative} frame ${index} touches its cell boundary (${bbox})"
    done
  done
}

assert_image assets/intro/production/ball/ball-bounce.webp 640x320
assert_image assets/intro/production/dog/dog-circle-settle.webp 1280x480
assert_image assets/intro/production/dog/dog-run-right.webp 1280x480
assert_image assets/intro/production/environment/intro-grass.webp 2560x640
assert_image assets/intro/production/intro-final-still.webp 768x768
assert_image assets/intro/production/person/summer-land-stand.webp 1536x768
assert_image assets/intro/production/person/summer-pulled-run-right.webp 1536x768
assert_image assets/intro/production/person/summer-trip-exit-right.webp 1536x768
assert_image assets/orbit/runtime/dog-orbit-run-8dir-4f.webp 1024x1536
assert_image assets/orbit/runtime/person-look-12dir.webp 1536x1026

for relative in \
  assets/intro/production/ball/ball-bounce.webp \
  assets/intro/production/dog/dog-circle-settle.webp \
  assets/intro/production/dog/dog-run-right.webp \
  assets/intro/production/intro-final-still.webp \
  assets/intro/production/person/summer-land-stand.webp \
  assets/intro/production/person/summer-pulled-run-right.webp \
  assets/intro/production/person/summer-trip-exit-right.webp \
  assets/orbit/runtime/dog-orbit-run-8dir-4f.webp \
  assets/orbit/runtime/person-look-12dir.webp; do
  assert_rgba_and_transparent_corners "${relative}"
done

jq -e '.version == 1 and .mode == "production"' \
  "${PACKAGE_ROOT}/assets/intro/production/intro-manifest.json" >/dev/null \
  || fail "intro-manifest.json contract mismatch"
jq -e '.package == "baozi-space-b-lite-assets-v1.0" and (.assets | length) == 16' \
  "${PACKAGE_ROOT}/spec/asset-manifest.json" >/dev/null \
  || fail "asset-manifest.json invalid"
jq -e '.version == "1.0.0" and .name == "baozi-space-b-lite"' \
  "${PACKAGE_ROOT}/spec/b-lite-style-contract.json" >/dev/null \
  || fail "b-lite-style-contract.json invalid"

intro_bytes="$(find "${PACKAGE_ROOT}/assets/intro/production" -type f -name '*.webp' -printf '%s\n' \
  | awk '{ total += $1 } END { print total + 0 }')"
[[ "${intro_bytes}" -le 6291456 ]] || fail "intro WebP payload exceeds 6 MiB"

dog_sheet="${PACKAGE_ROOT}/assets/orbit/runtime/dog-orbit-run-8dir-4f.webp"
tmp="$(mktemp -d)"
trap 'rm -rf "${tmp}"' EXIT

assert_sheet_cells_isolated assets/intro/production/ball/ball-bounce.webp 4 2 160 160
assert_sheet_cells_isolated assets/intro/production/dog/dog-circle-settle.webp 4 2 320 240
assert_sheet_cells_isolated assets/intro/production/dog/dog-run-right.webp 4 2 320 240
assert_sheet_cells_isolated assets/intro/production/person/summer-land-stand.webp 4 2 384 384
assert_sheet_cells_isolated assets/intro/production/person/summer-pulled-run-right.webp 4 2 384 384
assert_sheet_cells_isolated assets/intro/production/person/summer-trip-exit-right.webp 4 2 384 384
assert_sheet_cells_isolated assets/orbit/runtime/person-look-12dir.webp 4 3 384 342

for ((row = 0; row < 8; row += 1)); do
  for ((col = 0; col < 4; col += 1)); do
    index=$((row * 4 + col))
    convert "${dog_sheet}" -crop "256x192+$((col * 256))+$((row * 192))" +repage \
      -alpha extract -threshold 20% "${tmp}/dog-${index}.png"
    component_count="$(
      convert "${tmp}/dog-${index}.png" \
        -define connected-components:verbose=true -connected-components 8 null: 2>&1 \
        | awk '$NF == "gray(255)" && $(NF-1) > 20 { count += 1 } END { print count + 0 }'
    )"
    [[ "${component_count}" -eq 1 ]] \
      || fail "orbit dog frame ${index} has ${component_count} opaque components"

    bbox="$(identify -format '%@' "${tmp}/dog-${index}.png")"
    if [[ ! "${bbox}" =~ ^([0-9]+)x([0-9]+)\+([0-9]+)\+([0-9]+)$ ]]; then
      fail "cannot parse orbit dog frame ${index} bounds: ${bbox}"
    fi
    width="${BASH_REMATCH[1]}"
    height="${BASH_REMATCH[2]}"
    x="${BASH_REMATCH[3]}"
    y="${BASH_REMATCH[4]}"
    [[ "${x}" -ge 2 && "${y}" -ge 2 && $((x + width)) -le 254 && $((y + height)) -le 190 ]] \
      || fail "orbit dog frame ${index} touches its cell boundary (${bbox})"
  done
done

manifest_intro_bytes="$(jq -r '.introRuntimeWebpBytes' "${PACKAGE_ROOT}/spec/asset-manifest.json")"
[[ "${manifest_intro_bytes}" == "${intro_bytes}" ]] \
  || fail "manifest intro payload ${manifest_intro_bytes} != actual ${intro_bytes}"

while IFS=$'\t' read -r relative expected_sha; do
  [[ -f "${PACKAGE_ROOT}/${relative}" ]] || fail "manifest path missing: ${relative}"
  actual_sha="$(sha256sum "${PACKAGE_ROOT}/${relative}" | cut -d' ' -f1)"
  [[ "${actual_sha}" == "${expected_sha}" ]] \
    || fail "manifest SHA mismatch for ${relative}"
done < <(jq -r '.assets[] | [.path, .sha256] | @tsv' "${PACKAGE_ROOT}/spec/asset-manifest.json")

echo "PASS: dimensions, JSON, manifest SHA, transparent corners, 92 isolated cells, and ${intro_bytes}-byte intro payload"
