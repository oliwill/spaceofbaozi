# B-lite harness 接入说明

## 1. 启动动画

把 `assets/intro/production/` 的内容复制到项目的生产目录：

```text
public/assets/intro/production/
```

也可以先复制到：

```text
design-assets/intro/incoming-production/
```

然后沿用现有 A0-V 审计与发布流程。

无需修改：

- `intro-manifest.json`；本包与原文件字节一致。
- 8 帧、4 × 2 网格与单帧尺寸。
- `ground`、`center`、`hand`、`collar` 锚点。
- 9 fps、循环标记、时间线和草地退出区间。
- 小球文件与显示比例。

只把 `assets/intro/production/` 发布到 `public/`；`assets/intro/source/` 和 `qa/` 只用于设计审计。

## 2. 首页环绕动画

用以下两个文件替换现有环绕运行时素材：

```text
assets/orbit/runtime/person-look-12dir.webp
assets/orbit/runtime/dog-orbit-run-8dir-4f.webp
```

保持既有 `interaction-contract.json` 不变：

- 人物：4 列 × 3 行，384 × 342 单元，12 个 30° 方向。
- 小狗：4 列 × 8 行，256 × 192 单元，8 个方向 × 4 步。
- 人物注视角度继续来自小狗实际渲染位置。
- 小狗在人物后方时继续使用后层与 `0.92` 缩放，前方使用前层与 `1.04` 缩放。

本包重新标准化了小狗的单元边界。不要再对小狗做二次裁切、`trim` 或自动抠图，否则可能重新破坏各方向的统一底线。

## 3. 最低验收

1. 打开 `qa/intro-current-vs-b-lite.png`，确认 B-lite 只增强纸边、轮廓和暗部质感，没有改变身份和姿态。
2. 打开 `qa/orbit-b-lite-direction-check.png`，确认东/前/西/后姿态完整，小狗鼻子、尾巴、耳朵不被单元边界截断。
3. 打开 `qa/intro-final-still-alpha-check.png`，确认 fallback 静帧在深浅棋盘上无矩形底或透明纸屑。
4. 运行 harness 的 incoming-production audit、48 帧 contact sheet、Playwright 桌面/移动端与 reduced-motion 检查。
5. 在真实暖白点阵背景上以最终 CSS 显示尺寸复查；不要只在黑色透明预览底上判断白边强度。

## 4. 回滚

本包未改任何代码或数据接口。需要回滚时，只需恢复原 WebP 文件；Manifest 和交互契约无需回退。
