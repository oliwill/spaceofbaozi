# baozi.space B-lite 视觉素材增量包 v1.0

本包把已确认的 B-lite 印刷拼贴处理应用到启动动画、首页人物/小狗环绕动画与草地，同时保持原有水彩身份、精灵顺序和运行时接口。

## B-lite 的处理范围

- 人物与小狗：暖白剪纸边、细深靛轮廓、极轻蓝绿套色偏移。
- 暗部：只在帽子、短裤、小狗腹部/阴影等区域加入稀疏低透明网点。
- 草地：保留绿色水彩与原有靛蓝排线，只增强上缘深绿断线和暗部斑驳。
- 小球：保持原黄色、尺寸和现有文件，不重新处理。
- 不使用像素化、全局半调、霓虹错位、厚表情包描边或纯色矢量化。

## 运行时文件

### 启动动画

`assets/intro/production/` 中的路径、文件名、尺寸和 `intro-manifest.json` 与现有 harness 契约一致，可直接替换：

```text
ball/ball-bounce.webp                         640 × 320   原样保留
dog/dog-run-right.webp                       1280 × 480  4 × 2
dog/dog-circle-settle.webp                   1280 × 480  4 × 2
person/summer-pulled-run-right.webp           1536 × 768  4 × 2
person/summer-trip-exit-right.webp            1536 × 768  4 × 2
person/summer-land-stand.webp                 1536 × 768  4 × 2
environment/intro-grass.webp                  2560 × 640
intro-final-still.webp                         768 × 768
intro-manifest.json
```

WebP 总负载为 `694,110 bytes`，远低于启动素材契约的 6 MiB 上限。

### 首页环绕动画

```text
assets/orbit/runtime/person-look-12dir.webp       1536 × 1026  4 × 3
assets/orbit/runtime/dog-orbit-run-8dir-4f.webp   1024 × 1536  4 × 8
```

人物仍从屏幕右侧开始、每 30° 顺时针一帧；小狗仍按东、东南、南、西南、西、西北、北、东北排列，每行 4 步。

小狗源表额外完成了一项兼容性修复：从整张源图重新分离 32 个完整姿态，等比例缩放并回填到 `256 × 192` 单元，清除了跨格截断和透明纸屑。方向顺序和交互参数不变。

## 目录

| 目录 | 用途 |
| --- | --- |
| `assets/intro/production/` | harness 可直接发布的启动运行时文件 |
| `assets/intro/source/` | B-lite 无损 PNG，不复制进 `public/` |
| `assets/orbit/runtime/` | 首页环绕运行时 WebP |
| `assets/orbit/source/` | 标准化及 B-lite 无损 PNG |
| `qa/` | 同帧对照、四方位与透明度检查图 |
| `spec/` | B-lite 视觉约束、接入与资产清单 |
| `tools/` | 可复现的 ImageMagick 构建脚本 |

## 接入

具体替换步骤见 `spec/harness-integration.md`。启动动画不需要修改 Manifest、锚点或时间线；首页环绕不需要修改方向映射、轨道、阻尼或前后层级算法。

## 重新构建

需要 ImageMagick 6：

```bash
./tools/build-b-lite.sh /path/to/workspace
./tools/build-previews.sh /path/to/workspace
```

脚本按单元格处理人物/小狗，避免纸边或套色跨入相邻帧。
